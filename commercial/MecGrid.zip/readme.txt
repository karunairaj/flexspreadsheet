//******************************************
// Directory List information
//******************************************

- (MecGridLib)
  Source code of MecGrid library

- (MecGridLib/release)
  release version of MecGrid Library (version 1.0.4)
  Trial watermark removed.

- (MecGridForOLAP)
  OLAP Sample with sourcecode
  This feature needs ADOBE Flex datavisualization extension

- (MecGridSample)
  Sample code using MecGrid Library

- (MecGridMineSweepGame)
  Windows MineSweep Game Clone using MecGrid

//******************************************